#ifndef HASHING_H_INCLUDED
#define HASHING_H_INCLUDED

#include "Lista.h"

class Hashing
{
private:
    Lista** vet;
    int tamanho_tabela;
    int quant_colisoes;
public:
    // Construtor e Destrutor
    Hashing(int _tam);
    ~Hashing();

    int get_tamanho();
    int f(char* str);
    void insere(Book* b);
    void imprime();
    int get_quantColisoes();
    void consulta(char* str);
};

#endif // HASHING_H_INCLUDED
