#include "Book.h"
#include <iostream>
#include <cstring>
using namespace std;

Book::Book()
{
    ISBN = 0;
    title = 0;
    author = 0;
    publisher = 0;
    yearOfPublication = 0;
    prox = 0;
}

Book::~Book()
{
    delete[] ISBN;
    ISBN = 0;
    delete[] title;
    title = 0;
    delete[] author;
    author = 0;
    delete[] publisher;
    publisher = 0;
}

char* Book::get_ISBN()
{
    return ISBN;
}

char* Book::get_title()
{
    return title;
}

char* Book::get_author()
{
    return author;
}

int Book::get_yearOfPublication()
{
    return yearOfPublication;
}

char* Book::get_publisher()
{
    return publisher;
}

Book* Book::get_prox()
{
    return prox;
}

void Book::set_ISBN(char* _ISBN)
{
    delete[] ISBN;
    ISBN = new char[strlen(_ISBN) + 1];
    strcpy(ISBN, _ISBN);
}

void Book::set_title(char* _title)
{
    delete[] title;
    title = new char[strlen(_title) + 1];
    strcpy(title, _title);
}

void Book::set_author(char* _author)
{
    delete[] author;
    author = new char[strlen(_author) + 1];
    strcpy(author, _author);
}

void Book::set_yearOfPublication(int _year)
{
    yearOfPublication = _year;
}

void Book::set_publisher(char* _publisher)
{
    delete[] publisher;
    publisher = new char[strlen(_publisher) + 1];
    strcpy(publisher, _publisher);
}

void Book::set_prox(Book* _prox)
{
    prox = _prox;
}

void Book::print()
{
    cout << "ISBN: " << (ISBN ? ISBN : "N/A") << endl
         << "Title: " << (title ? title : "N/A") << endl
         << "Author: " << (author ? author : "N/A") << endl
         << "Year of Publication: " << yearOfPublication << endl
         << "Publisher: " << (publisher ? publisher : "N/A") << endl;
}
