#include "Arquivo.h"
#include "Hashing.h"
#include<iostream>
#include<cstring>
#include<fstream>
using namespace std;

Arquivo::Arquivo(char* _nome_arquivo)
{
    nome_arquivo = new char[strlen(_nome_arquivo)+1];
    strcpy(nome_arquivo, _nome_arquivo);
}
Arquivo::~Arquivo()
{
    delete [] nome_arquivo;
}
void Arquivo::substring(char* linha, char* aux, int &i, char delim)
{
    int k=0;
    if(linha[i] == '\"'){
        delim = '\"';
        i++;
    }
    while(linha[i]!=delim)
    {
        aux[k] = linha[i];
        i++;
        k++;
    }
    aux[k]='\0';
    i++;
}
void Arquivo::separa_atributos(char* linha, Book* b)
{
    char aux[MAX_CHARS];
    int i = 0;

    // Extrai o ISBN
    substring(linha, aux, i, ';');
    b->set_ISBN(aux);

    // Extrai o t�tulo
    substring(linha, aux, i, ';');
    b->set_title(aux);

    // Extrai o autor
    substring(linha, aux, i, ';');
    b->set_author(aux);

    // Extrai o ano de publica��o
    substring(linha, aux, i, ';');
    b->set_yearOfPublication(atoi(aux));

    // Extrai o nome da editora (publisher)
    substring(linha, aux, i, '\0');
    b->set_publisher(aux);
}
bool Arquivo::carrega_csv(Hashing* h)
{
    ifstream fin;

    fin.open(nome_arquivo);
    if(!fin.is_open()){
        cout << "Erro ao abrir o arquivo!";
        return false;
    }

    Book *b;
    char linha[MAX_CHARS_LINE];
    fin.getline(linha, MAX_CHARS_LINE);

    while(fin.getline(linha, MAX_CHARS_LINE))
    {
        b = new Book();
        separa_atributos(linha, b);

        h->insere(b);
    }
    fin.close();

    return true;
}
