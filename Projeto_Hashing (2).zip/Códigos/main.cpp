#include "Hashing.h"
#include "Arquivo.h"
#include<iostream>
#include<fstream>
using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    char nome_arq[] = "books1.csv";
    Arquivo *arq = new Arquivo(nome_arq);

    int tam;
    cout << "Entre com o tamanho da tabela hash: ";
    cin >> tam;

    Hashing* h = new Hashing(tam);
    if(arq->carrega_csv(h))
    {
        // Imprima a tabela hash

        // Imprima a quantidade de colis�es

        // Fa�a algumas consultas � tabela hash
    }

    delete h;
    delete arq;

    return 0;
}


