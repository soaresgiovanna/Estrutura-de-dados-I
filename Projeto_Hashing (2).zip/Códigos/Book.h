#ifndef BOOK_H_INCLUDED
#define BOOK_H_INCLUDED

class Book {
private:
    char* ISBN;
    char* title;
    char* author;
    int yearOfPublication;
    char* publisher;
    Book* prox; // Mantido 'prox' para encadeamento

public:
    // Construtor and Destrutor
    Book();
    ~Book();

    // Getters
    char* get_ISBN();
    char* get_title();
    char* get_author();
    int get_yearOfPublication();
    char* get_publisher();
    Book* get_prox();

    // Setters
    void set_ISBN(char* _ISBN);
    void set_title(char* _title);
    void set_author(char* _author);
    void set_yearOfPublication(int _year);
    void set_publisher(char* _publisher);
    void set_prox(Book* _prox);

    // M�todo de impress�o
    void print();
};


#endif // BOOK_H_INCLUDED
