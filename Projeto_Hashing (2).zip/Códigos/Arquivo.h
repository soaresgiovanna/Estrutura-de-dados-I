#ifndef ARQUIVO_H_INCLUDED
#define ARQUIVO_H_INCLUDED

#include <fstream>
using namespace std;
#include "Book.h"
#include "Hashing.h"

const int MAX_CHARS=500;
const int MAX_CHARS_LINE=1000;

class Arquivo
{
private:
    char* nome_arquivo;
    void substring(char* linha, char* aux, int &i, char delim);
    void separa_atributos(char* linha, Book* b);
public:
    Arquivo(char* _nome_arquivo);
    ~Arquivo();
    bool carrega_csv(Hashing* h);
};


#endif // ARQUIVO_H_INCLUDED
